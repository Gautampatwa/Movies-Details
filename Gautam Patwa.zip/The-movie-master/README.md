# The-movie
An android application which will update you about top rated movies and upcoming movies.
