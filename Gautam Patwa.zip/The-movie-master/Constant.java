package com.dryfire.themovie.Util;

public class Constant {

   public static final String API_KEY = "https://api.themoviedb.org/3/movie/{movie_id}/account_states?"+
           "api_key=994b289a5804f02279e036e5b8f976";
}
